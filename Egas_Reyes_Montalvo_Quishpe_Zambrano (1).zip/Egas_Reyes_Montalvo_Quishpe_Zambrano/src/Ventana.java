import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Ventana {
    private JPanel Principal;
    private JTextField faccionTXT;
    private JTextField podertxt;
    private JTextArea textArea1;
    private JButton button1;
    private JTextField nombreTXT;
    private JTextField funciontxt;
    private JTextArea textArea2;
    private JButton copiarTransformerButton;
    private JButton mostrarButton;
    ColaTransformers cola=new ColaTransformers();

    public Ventana() {

        /*Some Transformers that we can remenber.*/

        button1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String faccion = faccionTXT.getText();
                int poder = Integer.parseInt(podertxt.getText());
                String nombre= nombreTXT.getText();
                String fun = funciontxt.getText();
                Transformer nuevo = new Transformer(nombre,fun,poder,fun);
                cola.encolar(nuevo);
                textArea1.setText(nuevo.toString());
            }

        });
        copiarTransformerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {

            }
        });
        mostrarButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                cola.imprimirl(textArea1);
            }
        });
        copiarTransformerButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                String faccion = faccionTXT.getText();
                int poder = Integer.parseInt(podertxt.getText());
                String nombre= nombreTXT.getText();
                String fun = funciontxt.getText();
                Transformer nuevo = new Transformer(nombre,fun,poder,fun);
                cola.copy(textArea2,nuevo);
            }
        });
    }

    public static void main(String[] args) {
        JFrame frame = new JFrame("Ventana");
        frame.setContentPane(new Ventana().Principal);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
}
