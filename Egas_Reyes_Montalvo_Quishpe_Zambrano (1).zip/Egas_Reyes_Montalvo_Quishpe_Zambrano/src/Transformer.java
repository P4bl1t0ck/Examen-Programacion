public class Transformer {

    public String nombre;
    public String Faccion;
    public int poder;
    public String funcion;

    public Transformer(String nombre, String faccion, int poder, String funcion) {
        this.nombre = nombre;
        this.Faccion = faccion;
        this.poder = poder;
        this.funcion = funcion;
    }

    public Transformer() {
        this.nombre="";
        this.Faccion="";
        this.funcion="";
        this.poder=0;
    }

    @Override
    public String toString() {
        return "Transformer{" +
                "nombre='" + nombre + '\'' +
                ", Faccion='" + Faccion + '\'' +
                ", poder=" + poder +
                ", funcion='" + funcion + '\'' +
                '}';
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getFaccion() {
        return Faccion;
    }

    public void setFaccion(String faccion) {
        Faccion = faccion;
    }

    public int getPoder() {
        return poder;
    }

    public void setPoder(int poder) {
        this.poder = poder;
    }

    public String getFuncion() {
        return funcion;
    }

    public void setFuncion(String funcion) {
        this.funcion = funcion;
    }
}
