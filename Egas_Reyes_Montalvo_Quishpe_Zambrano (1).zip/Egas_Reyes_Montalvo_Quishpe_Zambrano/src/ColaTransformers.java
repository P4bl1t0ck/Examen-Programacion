import javax.swing.*;
import javax.swing.tree.TreeNode;
import java.util.LinkedList;
import java.util.Queue;

public class ColaTransformers {
    public Queue<Transformer> jf;

    public ColaTransformers(){
        this.jf = new LinkedList<>();
        Transformer a = new Transformer("CliffJumper","Autobot",90,"Guerrero");
        Transformer b = new Transformer("Arce","Autobot",75,"Guerrero");
        Transformer c = new Transformer("Bumblebee","Autobot",95,"Guerrero");
        Transformer e = new Transformer("Ratchet","Autobot",80,"Medico");
        Transformer d = new Transformer("Optimus","Autobot",150,"Guerrero");
        Transformer f = new Transformer("StarScream","Deceptico",80,"Guerrero");
        Transformer g = new Transformer("Badasstetron","Decepticon",0,"Guerrero");
        /*Some Transformers that we can remenber.*/
        jf.add(a);
        jf.add(b);
        jf.add(c);
        jf.add(d);
        jf.add(e);
        jf.add(f);
        jf.add(g);
        /*Asi es como se les quema a los datos dentro de nuestra cola.*/
    }

    public void encolar(Transformer nuevo){
        jf.add(nuevo);
    }


    public void desencolar() {
        jf.poll();
    }

    public int ataque(Transformer trans){
        if(trans.Faccion == "Decepticon"){
            int poder = (int) (trans.poder * 0.2);
            return poder;
        } else if (trans.Faccion == "Autobot") {
            int poder = (int) (trans.poder * 0.1);
            return poder;
        }else{
            return 0;
        }
    }
    public void imprimirl(JTextArea textArea){
        /*Creamos un stringbuilder que  guardara a todos los elementos de nuestra cola
        * y luego en un for mejorado que guardara en t los objetos, se setteara en el textarea.*/
        StringBuilder nuevo = new StringBuilder();
        for (Transformer t : jf) {
            nuevo.append(t.toString());
        }
        textArea.setText(nuevo.toString());
    }
    public void copy (JTextArea textArea,Transformer fas){
        for (Transformer t : jf){
            jf.add(fas);
            imprimirl(textArea);
        }
    }


}
